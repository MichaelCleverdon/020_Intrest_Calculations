/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg020_interest_calculation;

import javax.swing.JOptionPane;

/**
 *
 * @author compsci
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println(Interest());
        
        
        
        
        
    }

    private static String Interest() {
         double Principle;
        double Rate;
        double Period;
        
        
        Principle = Double.parseDouble(JOptionPane.showInputDialog(null, "What is the loan amount?"));
        Rate = Double.parseDouble(JOptionPane.showInputDialog(null, "What is your interest rate as a percent?"));
        Period = Double.parseDouble(JOptionPane.showInputDialog(null, "How long is the loan for in years?"));
        Rate = Rate/100;
        System.out.println(Rate);
        double Time = Period*12;
        
      
        double Numerator = (Rate*Math.pow(1+Rate, Time));
        System.out.println(Numerator);
        double Denominator = (Math.pow(1+Rate, Time)-1);
        System.out.println(Denominator);
        double total;
        double fraction = Numerator/Denominator;
        total = Principle*fraction;
        return (total+Principle)/Time + " is your monthly payment";
    }
    
}
